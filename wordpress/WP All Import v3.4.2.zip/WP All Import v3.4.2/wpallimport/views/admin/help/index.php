<h2><?php _e('WP All Import Help', 'pmxi_plugin') ?></h2>
	
