<?php

class WPML_Locale {

	public function init() {
		if ( $this->is_need_filter_title_sanitization() ) {
			add_filter( 'sanitize_title', array( $this, 'filter_sanitize_title' ), 10, 2 );
		}
	}

	/**
	 * Hooked to 'sanitize_title' in case the user is using a language that has either German or Danish locale, to
	 * ensure that WP Core sanitization functions handle special chars accordingly.
	 *
	 * @param string $title
	 * @param string $raw_title
	 *
	 * @return string
	 */
	public function filter_sanitize_title( $title, $raw_title ) {

		if ( $title !== $raw_title ) {
			remove_filter( 'sanitize_title', array( $this, 'filter_sanitize_title' ), 10 );
			$chars                            = array();
			$chars[ chr( 195 ) . chr( 132 ) ] = 'Ae';
			$chars[ chr( 195 ) . chr( 133 ) ] = 'Aa';
			$chars[ chr( 195 ) . chr( 134 ) ] = 'Ae';
			$chars[ chr( 195 ) . chr( 150 ) ] = 'Oe';
			$chars[ chr( 195 ) . chr( 152 ) ] = 'Oe';
			$chars[ chr( 195 ) . chr( 156 ) ] = 'Ue';
			$chars[ chr( 195 ) . chr( 159 ) ] = 'ss';
			$chars[ chr( 195 ) . chr( 164 ) ] = 'ae';
			$chars[ chr( 195 ) . chr( 165 ) ] = 'aa';
			$chars[ chr( 195 ) . chr( 166 ) ] = 'ae';
			$chars[ chr( 195 ) . chr( 182 ) ] = 'oe';
			$chars[ chr( 195 ) . chr( 184 ) ] = 'oe';
			$chars[ chr( 195 ) . chr( 188 ) ] = 'ue';
			$title                            = sanitize_title( strtr( $raw_title, $chars ) );
			add_filter( 'sanitize_title', array( $this, 'filter_sanitize_title' ), 10, 2 );
		}

		return $title;
	}

	public function locale() {
		global $locale, $sitepress;

		add_filter( 'language_attributes', array( $this, '_language_attributes' ) );

		if ( wpml_is_ajax() && isset( $_REQUEST[ 'action' ] ) && isset( $_REQUEST[ 'lang' ] ) ) {
			$locale_lang_code = $_REQUEST[ 'lang' ];
		} elseif ( is_admin()
				   && ( ! wpml_is_ajax()
						|| ( isset( $_SERVER[ 'HTTP_REFERER' ] )
							 && strpos( $_SERVER[ 'HTTP_REFERER' ], '/wp-admin/' ) !== false ) )
		) {
			$locale_lang_code = $sitepress->user_lang_by_authcookie();
		} else {
			$locale_lang_code = $sitepress->get_current_language();
		}

		$locale = $this->get_locale( $locale_lang_code );

		// theme localization
		remove_filter( 'locale', array( $sitepress, 'locale' ) ); //avoid infinite loop
		static $theme_locales_loaded = false;
		if ( ! $theme_locales_loaded
			 && (bool) $sitepress->get_setting( 'theme_localization_load_textdomain' ) === true
			 && (bool) $sitepress->get_setting( 'gettext_theme_domain_name' ) === true
			 && (bool) $sitepress->get_setting( 'theme_language_folders' ) === true
		) {
			$theme_folder_settings = $sitepress->get_setting( 'theme_language_folders' );
			foreach ( $theme_folder_settings as $folder ) {
				load_textdomain( $sitepress->get_setting( 'gettext_theme_domain_name' ),
								 $folder . '/' . $locale . '.mo' );
			}
			$theme_locales_loaded = true;
		}
		add_filter( 'locale', array( $sitepress, 'locale' ) );

		return $locale;
	}

	public function get_locale( $code ) {
		global $wpdb;
		$all_locales = null;

		if ( is_null( $code ) ) {
			return false;
		}

		$found  = false;
		$locale = wp_cache_get( 'get_locale' . $code, '', false, $found );
		if ( $found ) {
			return $locale;
		}

		$all_locales_data = $wpdb->get_results( "SELECT code, locale FROM {$wpdb->prefix}icl_locale_map" );
		foreach ( $all_locales_data as $locales_data ) {
			$all_locales[ $locales_data->code ] = $locales_data->locale;
		}

		$locale = isset( $all_locales[ $code ] ) ? $all_locales[ $code ] : false;

		if ( $locale === false ) {
			$this_locale_data = $wpdb->get_row( $wpdb->prepare( "SELECT code, default_locale FROM {$wpdb->prefix}icl_languages WHERE code = %s",
																$code ) );
			if ( $this_locale_data ) {
				$locale = $this_locale_data->default_locale;
			}
		}

		wp_cache_set( 'get_locale' . $code, $locale );

		return $locale;
	}

	public function switch_locale( $lang_code = false ) {
		global $l10n;
		static $original_l10n;
		if ( ! empty( $lang_code ) ) {
			$original_l10n = isset( $l10n[ 'sitepress' ] ) ? $l10n[ 'sitepress' ] : null;
			if ( $original_l10n !== null ) {
				unset( $l10n[ 'sitepress' ] );
			}
			load_textdomain( 'sitepress',
							 ICL_PLUGIN_PATH . '/locale/sitepress-' . $this->get_locale( $lang_code ) . '.mo' );
		} else { // switch back
			$l10n[ 'sitepress' ] = $original_l10n;
		}
	}

	public function get_locale_file_names() {
		global $wpdb;
		$locales = array();
		$res     = $wpdb->get_results( "
			SELECT lm.code, locale
			FROM {$wpdb->prefix}icl_locale_map lm JOIN {$wpdb->prefix}icl_languages l ON lm.code = l.code AND l.active=1" );
		foreach ( $res as $row ) {
			$locales[ $row->code ] = $row->locale;
		}

		return $locales;
	}

	public function set_locale_file_names( $locale_file_names_pairs ) {
		global $wpdb;
		$lfn = $this->get_locale_file_names();

		$new = array_diff( array_keys( $locale_file_names_pairs ), array_keys( $lfn ) );
		if ( ! empty( $new ) ) {
			foreach ( $new as $code ) {
				$wpdb->insert( $wpdb->prefix . 'icl_locale_map',
							   array( 'code' => $code, 'locale' => $locale_file_names_pairs[ $code ] ) );
			}
		}
		$remove = array_diff( array_keys( $lfn ), array_keys( $locale_file_names_pairs ) );
		if ( ! empty( $remove ) ) {
			$wpdb->query( "DELETE FROM {$wpdb->prefix}icl_locale_map
                           WHERE code IN (" . wpml_prepare_in( $remove ) . ")" );
		}

		$update = array_diff( $locale_file_names_pairs, $lfn );
		foreach ( $update as $code => $locale ) {
			$wpdb->update( $wpdb->prefix . 'icl_locale_map', array( 'locale' => $locale ), array( 'code' => $code ) );
		}

		return true;
	}

	private function is_need_filter_title_sanitization() {
		global $sitepress;

		$active_languages = $sitepress->get_active_languages();
		$needs_filter     = false;
		foreach ( $active_languages as $lang ) {
			if ( in_array( $lang[ 'default_locale' ], array( 'de_DE', 'da_DK' ) ) ) {
				$needs_filter = true;
				break;
			}
		}

		return $needs_filter;
	}

	function _language_attributes( $latr ) {
		global $locale;
		$latr = preg_replace( '#lang="(.[a-z])"#i', 'lang="' . str_replace( '_', '-', $locale ) . '"', $latr );

		return $latr;
	}

}