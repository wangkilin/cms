<?php
	$WPML_Translate_Taxonomy = new WPML_Taxonomy_Translation();
	$WPML_Translate_Taxonomy->render();

